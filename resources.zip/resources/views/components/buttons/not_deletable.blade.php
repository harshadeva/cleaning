<button type='button' onclick="notDeletableAlert()" title="This record is not deletable "
                                    class='btn btn-secondary  btn-rounded '>
                                    <i class='fa fa-trash'></i>
                                </button>
