<button type='button' onclick="notEditableAlert()" title="This record is not editable "
                                    class='btn btn-secondary  btn-rounded '>
                                    <i class='fa fa-edit'></i>
                                </button>
