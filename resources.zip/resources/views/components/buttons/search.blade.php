<button class="btn btn-success {{$classes ?? ''}}"><i class="fa fa-search"></i> {{ __('common.Search') }} </button>
