<div class="widgetbar">
    <a href="{{ $url ?? url()->previous() }}" class="btn btn-back"><i class="feather icon-chevron-left mr-2"></i>{{ __('common.Back') }}</a>
</div>
