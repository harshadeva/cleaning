 <div  style="pointer-events: none" aria-live="polite" aria-atomic="true">
     <div class="toast" role="alert" aria-live="assertive" aria-atomic="true"
         style="position: absolute; top: 30px; right: 30px;" id="error-toast">
         <div class="toast-header bg-danger">
             <i class="feather icon-alert-triangle text-white mr-2"></i>
             <span class="toast-title text-white mr-auto">Error</span>
         </div>
         <div id="error-toast-text" class="toast-body text-danger">
         </div>
     </div>
 </div>
