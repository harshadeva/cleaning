<a style="margin-top: 8px" href="{{ $url }}"
                        class="btn btn-primary">{{ $label ?? __('common.Add New')}}</a>
