<li>
    <a href="{{ $route }}">
        <i class="{{ $icon }} text-muted"></i><span>{{ $label }}</span>
    </a>
</li>
