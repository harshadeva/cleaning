 <div class="card m-b-30">
     <div class="card-body">
         <div class="row">
             <div class="col-md-12 text-center">
                 <h5 class="{{ $class }}"> <span class="{{ $icon }}"></span> {{ $name }}</h5> <hr/>
                 <strong class="{{ $class }}">{{ $value }}</strong>
             </div>
         </div>
     </div>
 </div>
