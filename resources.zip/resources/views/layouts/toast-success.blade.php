 <div style="pointer-events: none" aria-live="polite" aria-atomic="true">
     <div class="toast" role="alert" aria-live="assertive" aria-atomic="true"
         style="position: absolute; top: 30px; right: 30px;" id="succes-toast">
         <div class="toast-header bg-success">
             <i class="feather icon-check-circle text-white mr-2"></i>
             <span class="text-white toast-title mr-auto">Success</span>
         </div>
         <div id="success-toast-text" class="toast-body text-dark">
         </div>
     </div>
 </div>
